def alternate_pos_neg(arr):
    pos_arr = []
    neg_arr = []
    for num in arr:
        if num >= 0:
            pos_arr.append(num)
        else:
            neg_arr.append(num)
    result = []
    pos_idx = 0
    neg_idx = 0
    while pos_idx < len(pos_arr) and neg_idx < len(neg_arr):
        result.append(neg_arr[neg_idx])
        result.append(pos_arr[pos_idx])
        neg_idx += 1
        pos_idx += 1
    if pos_idx < len(pos_arr):
        result.extend(pos_arr[pos_idx:])
    elif neg_idx < len(neg_arr):
        result.extend(neg_arr[neg_idx:])

    return result
arr = [1, 2, 3, -4, -1, 4]
print(alternate_pos_neg(arr))

