#include <stdio.h>

void move_zeros_to_left(int arr[], int size) {
    int arr_first = size - 1;
    int arr_second = size - 1;
    while (arr_second >= 0) {
        if (arr[arr_second] != 0) {
            int temp = arr[arr_first];
            arr[arr_first] = arr[arr_second];
            arr[arr_second] = temp;
            arr_first--;
        }
        arr_second--;
    }
}
int main() {
    int arr[] = {1, 10, 20, 0, 59, 63, 0, 88, 0};
    int size = sizeof(arr) / sizeof(arr[0]);

    printf("Before: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    move_zeros_to_left(arr, size);

    printf("After: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}
