def find_repeating_numbers(arr):
    n = len(arr)
    repeating_numbers = []
    
    for i in range(n):
        index = abs(arr[i])
        if arr[index] < 0:
            repeating_numbers.append(index)
        else:
            arr[index] = -arr[index]
    
    print("Repeating numbers:", repeating_numbers)
arr = [1, 2, 3, 6, 3, 6, 1]
find_repeating_numbers(arr)
