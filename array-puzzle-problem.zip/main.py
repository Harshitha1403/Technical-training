def product_array(arr):
    n = len(arr)
    product = 1
    for i in range(n):
        product *= arr[i]

    output = [0] * n
    for i in range(n):
        output[i] = product // arr[i]

    return output

arr = [10, 3, 5, 6, 2]
output = product_array(arr)
print(output)