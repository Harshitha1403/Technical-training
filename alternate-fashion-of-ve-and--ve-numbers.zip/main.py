def arrange_alternate(arr):
    n = len(arr)
    pos_ptr = 0
    neg_ptr = 0
    
    # Find the first positive and negative elements in the array
    while pos_ptr < n and arr[pos_ptr] < 0:
        pos_ptr += 1
    neg_ptr = pos_ptr + 1
    
    # Swap the positive and negative elements
    while pos_ptr < n and neg_ptr < n:
        if arr[pos_ptr] < 0:
            pos_ptr += 1
        elif arr[neg_ptr] > 0:
            neg_ptr += 1
        else:
            arr[pos_ptr], arr[neg_ptr] = arr[neg_ptr], arr[pos_ptr]
            pos_ptr += 1
            neg_ptr += 1
    
    return arr
arr = [1, 2, 3, -4, -1, 4]
print(arrange_alternate(arr))
