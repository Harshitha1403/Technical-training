def count_pairs_with_sum(arr, sum):
    count = 0
    n = len(arr)
    for i in range(n):
        for j in range(i+1, n):
            if arr[i] + arr[j] == sum:
                count += 1
    return count
arr = [1, 5, 7, -1]
sum = 6
count = count_pairs_with_sum(arr, sum)
print(count)