def find_first_repeating_element(arr):
    n = len(arr)
    freq = {}
    
    for i in range(n):
        if arr[i] in freq and freq[arr[i]] > 0:
            return i
        else:
            freq[arr[i]] = 1
    
    return -1
arr = [10, 5, 3, 4, 3, 5, 6]
print("Index of first repeating element:", find_first_repeating_element(arr))
