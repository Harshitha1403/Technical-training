def smallest_missing_positive(arr):
    n = len(arr)
    present = [False] * n
    for num in arr:
        if num > 0 and num <= n:
            present[num - 1] = True
    for i in range(n):
        if present[i] == False:
            return i + 1
    return n + 1
arr = [2, 3, 7, 6, 8, -1, -10, 15]
print(smallest_missing_positive(arr)) # Output: 1

