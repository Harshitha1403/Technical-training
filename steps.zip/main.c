#include <stdio.h>

int noofWays(int n) {
    if (n == 0 || n == 1) {
        return 1;
    } else {
        return noofWays(n-1) + noofWays(n-2);
    }
}

int main() {
    int n;
    printf("Enter the number of steps: ");
    scanf("%d", &n);
    printf("Number of ways to climb the stairs: %d", noofWays(n));
    return 0;
}
