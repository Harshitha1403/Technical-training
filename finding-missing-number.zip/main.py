def find_missing_number(arr, N):
    sum_of_array = sum(arr)
    sum_of_N_numbers = N*(N+1)//2
    missing_number = sum_of_N_numbers - sum_of_array
    return missing_number

arr = [1, 2, 4, 5, 3, 7, 8]
N = 8
missing_number = find_missing_number(arr, N)
print(missing_number)