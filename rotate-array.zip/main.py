def left_rotate_array(arr, d):
   
    temp_arr = arr[:d]
   
   
    for i in range(d, len(arr)):
        arr[i-d] = arr[i]

    for i in range(d):
        arr[len(arr)-d+i] = temp_arr[i]
   
    return arr
arr = [1, 2, 3, 4, 5]
d = 2
rotated_arr = left_rotate_array(arr, d)
print(rotated_arr)  